#!/bin/sh
date=$(date '+%b %d %Y %a %H:%M:%S') 
printf " %s %s \\n" "$icon" "$date" 
