//Modify this file to change what commands output to your statusbar, and recompile using the make command.
static const Block blocks[] = {
	/*Icon*/	/*Command*/	 	/*Update Interval*/	/*Update Signal*/
	{"^c#f7768e^", 6, 3},
	{"  ^c#e0af68^", "/home/seb/.dwm/scripts/fs", 6, 3}, 
        {"^c#7dcfff^", 6, 3},
	{"  ^c#a9b1d6^", "/home/seb/.dwm/scripts/memory", 6, 3 },
//	{"^c#e4e4e4^", "/home/sebastian/.dwm/scripts/cpu", 1, 3},
        {"^c#ebc8dd^", 6, 3},
	{"  ^c#bb9af7^","/home/seb/.dwm/scripts/cpu_load",1,6},
//        {"^c#e4e4e4^","/home/seb/.dwm/scripts/ip.sh",1,3},
//        {"^c#2aa198^","/home/seb/.dwm/scripts/wetter.sh",7200,0},
//	{"^c#e4e4e4^", "/home/sebastian/.dwm/scripts/kernel",100,         15},
	 {"^c#c0caf5^", 6, 3},
	{" 󰅐 ^c#9ece6a^", "echo $(date +\"%a, %B %d %l:%M%p\"| sed 's/  / /g') ",			   60,		          0},
};

//sets delimeter between status commands. NULL character ('\0') means no delimeter.
static char delim[] = " ";
static unsigned int delimLen = 200;
#define CMDLENGTH		10000
