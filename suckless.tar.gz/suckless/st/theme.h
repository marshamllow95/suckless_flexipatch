
static const char *colorname[] = {
  	"#15161E",
  	"#f7768e",
  	"#9ece6a",
  	"#e0af68",
  	"#7aa2f7",
  	"#bb9af7",
  	"#7dcfff",
	"#a9b1d6",

	/* bright colors */

  	"#414868",
  	"#f7768e",
  	"#9ece6a",
  	"#e0af68",
  	"#7aa2f7",
  	"#bb9af7",
  	"#7dcfff",
  	"#c0caf5",

  	[255] = 0,

unsigned int defaultfg = 257;
unsigned int defaultbg = 256;
unsigned int defaultcs = 257;
static unsigned int defaultrcs = 257;

};



