static void enqueue(Client *c);
static void enqueuestack(Client *c);
static void rotatestack(const Arg *arg);

