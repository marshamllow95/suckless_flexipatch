static void reorganizetags(const Arg *arg);

