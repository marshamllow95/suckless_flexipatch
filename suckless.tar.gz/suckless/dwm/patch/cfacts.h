static void setcfact(const Arg *arg);

